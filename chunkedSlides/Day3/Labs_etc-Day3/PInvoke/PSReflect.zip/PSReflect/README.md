PSReflect
=========

Easily define in-memory enums, structs, and Win32 functions in PowerShell
